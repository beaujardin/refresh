MultiRefresh — installation
===========================

1. Dézippe ce dossier quelque part (garde le dossier "MultiRefresh").
2. Ouvre Chrome / Edge et va sur : chrome://extensions
3. Active "Mode développeur" (en haut à droite).
4. Clique sur "Charger l'extension non empaquetée".
5. Sélectionne le dossier "MultiRefresh".
6. Épingle l'extension dans la barre d'outils, ouvre-la sur le site voulu.

Utilisation
-----------
- Intervalle : 1 à 1000 ms (par défaut 1 ms).
- "Démarrer" lance le rafraîchissement de la page active ; "Arrêter" le stoppe.
- Le rafraîchissement ne dépend pas du chargement complet de la page : seul
  l'intervalle compte (minuteur basé sur l'horloge, démarré dès le début du document).
- Le rafraîchissement ne s'applique qu'au site sur lequel tu as démarré.
- Les domaines gabin.bertaud.net et bertaud.net sont exclus et ne seront jamais rafraîchis.
