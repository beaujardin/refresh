'use strict';

(function () {
  var BLOCKED = ['gabin.bertaud.net', 'bertaud.net'];

  var intervalEl = document.getElementById('interval');
  var toggleBtn = document.getElementById('toggle');
  var statusEl = document.getElementById('status');

  var currentHost = '';
  var enabled = false;

  function clamp(v) {
    v = parseInt(v, 10);
    if (!isFinite(v)) v = 1;
    return Math.max(1, Math.min(1000, v));
  }

  function hostOf(url) {
    try { return new URL(url).hostname.toLowerCase(); } catch (e) { return ''; }
  }

  function isBlocked(host) {
    host = (host || '').toLowerCase();
    for (var i = 0; i < BLOCKED.length; i++) {
      var d = BLOCKED[i];
      if (host === d || host.slice(-(d.length + 1)) === '.' + d) return true;
    }
    return false;
  }

  function save() {
    chrome.storage.local.set({
      mrState: { enabled: enabled, interval: clamp(intervalEl.value), host: currentHost }
    });
  }

  function paint() {
    toggleBtn.textContent = enabled ? 'Arrêter' : 'Démarrer';
    toggleBtn.classList.toggle('on', enabled);
    toggleBtn.classList.toggle('primary', !enabled);
    statusEl.textContent = enabled ? ('Actif sur ' + currentHost) : 'Arrêté';
    statusEl.classList.toggle('on', enabled);
  }

  function init() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs && tabs[0];
      currentHost = hostOf(tab && tab.url);

      chrome.storage.local.get('mrState', function (data) {
        var s = data.mrState || {};
        intervalEl.value = s.interval || 1;
        enabled = !!s.enabled && s.host === currentHost;

        if (!currentHost || isBlocked(currentHost)) {
          enabled = false;
          toggleBtn.disabled = true;
          statusEl.textContent = currentHost ? 'Site exclu' : 'Indisponible';
          statusEl.classList.remove('on');
          return;
        }
        paint();
      });
    });
  }

  toggleBtn.addEventListener('click', function () {
    if (toggleBtn.disabled) return;
    enabled = !enabled;
    if (enabled) intervalEl.value = clamp(intervalEl.value);
    save();
    paint();
  });

  intervalEl.addEventListener('change', function () {
    intervalEl.value = clamp(intervalEl.value);
    if (enabled) save();
  });

  init();
})();
