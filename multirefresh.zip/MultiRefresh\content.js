'use strict';

(function () {
  var BLOCKED = ['gabin.bertaud.net', 'bertaud.net'];
  var timer = null;
  var state = null;

  function isBlocked(host) {
    host = (host || '').toLowerCase();
    for (var i = 0; i < BLOCKED.length; i++) {
      var d = BLOCKED[i];
      if (host === d || host.slice(-(d.length + 1)) === '.' + d) return true;
    }
    return false;
  }

  function sameSite(host, target) {
    host = (host || '').toLowerCase();
    target = (target || '').toLowerCase();
    if (!target) return false;
    return host === target || host.slice(-(target.length + 1)) === '.' + target;
  }

  function clearTimer() {
    if (timer) { clearTimeout(timer); timer = null; }
  }

  function readNext() {
    try {
      var n = parseInt(sessionStorage.getItem('mrNextAt'), 10);
      return isFinite(n) && n > 0 ? n : 0;
    } catch (e) { return 0; }
  }

  function writeNext(n) {
    try { sessionStorage.setItem('mrNextAt', String(n)); } catch (e) {}
  }

  function readInterval() {
    try {
      var n = parseInt(sessionStorage.getItem('mrInterval'), 10);
      return isFinite(n) && n > 0 ? n : 0;
    } catch (e) { return 0; }
  }

  function writeInterval(n) {
    try { sessionStorage.setItem('mrInterval', String(n)); } catch (e) {}
  }

  function clearState() {
    try {
      sessionStorage.removeItem('mrNextAt');
      sessionStorage.removeItem('mrInterval');
    } catch (e) {}
  }

  function schedule() {
    clearTimer();

    if (!state || !state.enabled || isBlocked(location.hostname) || !sameSite(location.hostname, state.host)) {
      clearState();
      return;
    }

    var interval = Math.max(1, parseInt(state.interval, 10) || 1);
    var now = Date.now();
    var nextAt = readNext();

    if (readInterval() !== interval) {
      nextAt = now + interval;
      writeInterval(interval);
    }
    if (nextAt <= 0) nextAt = now + interval;
    if (nextAt < now - interval) nextAt = now + interval;

    writeNext(nextAt);

    timer = setTimeout(function () {
      timer = null;
      var t = Date.now();
      var next = nextAt + interval;
      if (next <= t) next = t + interval;
      writeNext(next);
      location.reload();
    }, Math.max(0, nextAt - now));
  }

  chrome.storage.local.get('mrState', function (data) {
    state = data.mrState;
    schedule();
  });

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === 'local' && changes.mrState) {
      state = changes.mrState.newValue;
      schedule();
    }
  });

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg && msg.type === 'mr-status') {
      sendResponse({
        host: location.hostname,
        blocked: isBlocked(location.hostname),
        active: timer !== null
      });
    }
    return true;
  });
})();
